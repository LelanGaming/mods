--
-- FS22 - Manual Cutting for Wood Harvester
-- @author:    	Ifko[nator], t0xic0m, kenny456 - FS19,FS22 conversion (kenny456@seznam.cz)
-- @history:	v1.0 - 2018-12-29 - converted to FS19
-- 				v1.0 - 2021-12-13 - converted to FS22
--
local modDirectory = g_currentModDirectory or ""
local modName = g_currentModName or "unknown"

source(modDirectory .. "manualCutting.lua")

local function initSpecialization(manager)
    if manager.typeName == "vehicle" then
        g_specializationManager:addSpecialization("manualCutting", "ManualCutting", modDirectory .. "manualCutting.lua", nil)

        for typeName, typeEntry in pairs(g_vehicleTypeManager:getTypes()) do
			if typeEntry ~= nil and typeName ~= "locomotive" and typeName ~= "trainTrailer" and typeName ~= "trainTimberTrailer" then 
				if SpecializationUtil.hasSpecialization(WoodHarvester, typeEntry.specializations)  then
					g_vehicleTypeManager:addSpecialization(typeName, modName .. ".manualCutting")
				end
            end
        end
    end
end

local function init()
    TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, initSpecialization)
end

init()
