--
-- FS22 - Manual Cutting for Wood Harvester
-- @author:    	Ifko[nator], t0xic0m, kenny456 - FS19,FS22 conversion (kenny456@seznam.cz)
-- @history:	v1.0 - 2018-12-29 - converted to FS19
-- 				v1.0 - 2021-12-13 - converted to FS22
--
ManualCutting = {};

function ManualCutting.prerequisitesPresent(specializations)
	return SpecializationUtil.hasSpecialization(WoodHarvester, specializations);
end

function ManualCutting.initSpecialization()
end

function ManualCutting.registerOverwrittenFunctions(vehicleType)
end

function ManualCutting.registerFunctions(vehicleType)
end

function ManualCutting.registerEvents(vehicleType)
end

function ManualCutting:registerActionEventsPlayer()
end

function ManualCutting:registerActionEventsMenu()
end
function ManualCutting:onRegisterActionEvents(isSelected, isOnActiveVehicle)
end

function ManualCutting.registerEventListeners(vehicleType)
    EL = vehicleType.eventListeners
    table.insert(EL.onLoad, ManualCutting)
    table.insert(EL.onUpdate, ManualCutting)
    table.insert(EL.onDraw, ManualCutting)
    table.insert(EL.onRegisterActionEvents, ManualCutting)
end

function ManualCutting:onLoad(vehicle)
	self.onDelimbTree = Utils.overwrittenFunction(self.onDelimbTree, ManualCutting.NEWonDelimbTree)
	self.readyCut = 0
end

function ManualCutting:NEWonDelimbTree(onDelimbTree, state)
	self.spec_woodHarvester.isAttachedSplitShapeMoving = state;
	if not state then
		if self.readyCut == 1 then
			self:cutTree(0)
			self.readyCut = 0
		else
			self.readyCut = 1
		end;
	end;
end;

function ManualCutting:onUpdate()
	if self.spec_woodHarvester.attachedSplitShape == nil and self.readyCut == 1 then
		self.readyCut = 0
	end;
end

function ManualCutting:onDraw()
end
