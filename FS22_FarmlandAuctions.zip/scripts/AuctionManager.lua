-- Author: Julius Becker
-- Bugreports: mod@becker-julius.de

AuctionManager = {}

local allFarmlands
local allUnownedFarmlandIds = {}
local currentAuction
local isInitialized = false
local pathToXML
local aiBets

addModEventListener(AuctionManager)

function AuctionManager:loadMap()
	FSBaseMission.update = Utils.appendedFunction(FSBaseMission.update, AuctionManager.update)
	FSBaseMission.saveSavegame = Utils.appendedFunction(FSBaseMission.saveSavegame, AuctionManager.saveSavegame)
    Player.onEnter = Utils.appendedFunction(Player.onEnter, AuctionManager.onEnter)
end

function AuctionManager:onEnter()
	if(not isInitialized)then
		isInitialized = true
		--Get all unowned farmlands
		AuctionManager:getUnownedFarmlands()
		
		pathToXML = g_currentMission.missionInfo:getSavegameDirectory(g_currentMission.missionInfo.savegameIndex) .. "/auction.xml"
		
		if fileExists(pathToXML) then
			currentAuction = Auction:loadFromXMLFile(pathToXML)
		else
			local farmlandID = allUnownedFarmlandIds[math.random( tablelength(allUnownedFarmlandIds)-1)]
			AuctionManager:generateNextAuction(farmlandID)
		end
	end
end

function AuctionManager:getUnownedFarmlands()
	allUnownedFarmlandIds = {}
	for key, value in pairs(g_farmlandManager:getFarmlands()) do
		if g_farmlandManager:getFarmlandOwner(key) == 0 then
			table.insert(allUnownedFarmlandIds, key)
		end
	end
end

function AuctionManager:update()
	if(currentAuction ~= nil and isInitialized) then
		
		if(currentAuction:isOutdated()) then
			currentAuction:auctionEnded()
			AuctionManager:getUnownedFarmlands()
			local farmlandID = allUnownedFarmlandIds[math.random( tablelength(allUnownedFarmlandIds)-1)]
			AuctionManager:generateNextAuction(farmlandID)
		end
		if(not currentAuction.oneHoureWarningSend and currentAuction:remainingTime()<=1) then
			g_currentMission:addIngameNotification({1,0.6,0,1},g_i18n:getText("EndInOneHour"),"SPTupdate")
			currentAuction.oneHoureWarningSend = true
		end
		if(currentAuction.currentPrice>currentAuction.maxPrice) then
			currentAuction.allBets = {}
		end
		if(currentAuction.allBets[1] ~= nil and currentAuction.allBets[1] <= g_currentMission.environment:getEnvironmentTime()+g_currentMission.environment.currentDay*24) then
			currentAuction:placeBid(FarmlandManager.NO_OWNER_FARM_ID)
			table.remove(currentAuction.allBets,1)
		end
		
		if(not currentAuction.hasStarted and g_currentMission.environment:getEnvironmentTime()+g_currentMission.environment.currentDay*24>=currentAuction.startTime) then
			AuctionManager:notifyFarmlandOnAuctionStart(currentAuction:getFarmlandID())
			currentAuction.hasStarted = true
		end
	end
end

function AuctionManager:draw()
	if(currentAuction ~= nil and isInitialized) then
		local playerPosX,_,playerPosZ,_ = g_currentMission.player:getPositionData()
        local farmlandBelowPlayer = g_farmlandManager:getFarmlandIdAtWorldPosition(playerPosX,playerPosZ)
        if farmlandBelowPlayer == currentAuction:getFarmlandID() then
            g_currentMission:addExtraPrintText(g_i18n:getText("KeyInfo") .. g_i18n:formatMoney(currentAuction.currentPrice + currentAuction.betStepSize)  .. g_i18n:getText("EndsLess") .. math.floor(currentAuction.endTime-(g_currentMission.environment:getEnvironmentTime()+g_currentMission.environment.currentDay*24)).."h")
        end
	end
end

function AuctionManager:saveSavegame()
	currentAuction:saveToXml(pathToXML)
end

function AuctionManager:generateNextAuction(farmlandID)

    local startHour = math.random(24)
	local endHour = math.random(24)	
	local startDay = 0
	if(g_currentMission.environment.growthMode == 1) then
		startDay = g_currentMission.environment.currentDay + math.random(g_currentMission.environment:getDaysPerSeason()*g_currentMission.environment.SEASONS_IN_YEAR) + 2
    else
		startDay = g_currentMission.environment.currentDay + math.random(5) + 2
	end
	local endDay = startDay + math.random(6)+1
--[[
	local startTime = g_currentMission.environment:getEnvironmentTime()
	local endTime = g_currentMission.environment:getEnvironmentTime()+1
    local startDay = g_currentMission.environment.currentDay
    local endDay = g_currentMission.environment.currentDay
]]
	local auctionName = g_i18n:getText("Field")
	local fieldsOnFarmland = {}
	
	for index,field in pairs(g_fieldManager.fields) do
		if field.farmland == g_farmlandManager:getFarmlandById(farmlandID) then
			table.insert(fieldsOnFarmland,index)
		end
	end
	
	if(#fieldsOnFarmland == 0)then
		--auctionName= " X="..math.floor(g_farmlandManager:getFarmlandById(farmlandID).xWorldPos) .. " Z=" .. math.floor(g_farmlandManager:getFarmlandById(farmlandID).zWorldPos)
		auctionName = g_i18n:getText("NoFieldsOnFarmland")
	else
		for key, value in pairs(fieldsOnFarmland) do
			if key < #fieldsOnFarmland-1 then
				auctionName = auctionName .. value ..", "
			end
		end
		auctionName = auctionName .. fieldsOnFarmland[#fieldsOnFarmland]
	end
    currentAuction = Auction:new(farmlandID,auctionName,startHour+startDay*24,endHour+endDay*24)
end

function AuctionManager:notifyFarmlandOnAuctionStart(farmlandID)

	local msg = g_i18n:getText("NewAuction") .. currentAuction.name
	local hours,days = AuctionManager:timeFormat(currentAuction.endTime - g_currentMission.environment:getEnvironmentTime()-g_currentMission.environment.currentDay*24)
	if days>0 then
		msg = msg .. g_i18n:getText("EndsLess") .. hours .. g_i18n:getText("Hours") .. g_i18n:getText("AndWord").. days .. g_i18n:getText("Days")
	else
		msg = msg .. g_i18n:getText("EndsLess") .. hours .. g_i18n:getText("Hours")
	end
	g_currentMission:addIngameNotification({0,1,0,1},msg,"SPTupdate")
	for _,field in pairs(g_fieldManager.fields) do
		if field.farmland == g_farmlandManager:getFarmlandById(farmlandID) then
			field.mapHotspot.color = {1,0.6,0,1}
		end
	end
	
end

function AuctionManager:keyEvent(unicode, sym, modifier, isDown)
    if Input.isKeyPressed(Input.KEY_b) then
		--[[local hotspot = MapHotspot:new("Auction", MapHotspot.CATEGORY_MISSION)
		local hotspot = MapHotspot.new()
		--hotspot:setColor({1.0,0.84,0})
		farmland = g_farmlandManager:getFarmlandById(currentAuction:getFarmlandID())
		hotspot:setWorldPosition(1000,1000) 
		--hotspot:setText("Forst",false,true)
		hotspot:setColor({1,1,1,1})
		hotspot:setBlinking(true)
		--hotspot:setPosition(farmland.xWorldPos,farmland.zWorldPos)
		
		local hotspot
		
		g_currentMission:addMapHotspot(hotspot)--]]
        local playerPosX,_,playerPosZ,_ = g_currentMission.player:getPositionData()
        local farmlandBelowPlayer = g_farmlandManager:getFarmlandIdAtWorldPosition(playerPosX,playerPosZ)
        if farmlandBelowPlayer == currentAuction:getFarmlandID() then
            currentAuction:placeBid(g_currentMission.player.farmId)
        end
    end
end

function AuctionManager:timeFormat(timeInHours)
	local hours = math.floor(timeInHours%24)
	local days = math.floor(timeInHours/24)
	if(hours >= 24) then
		days = days +1
		hours = hours-24
	end
	return hours,days
end

function tablelength(T)
    if T~=nil then
      local count = 0
      for _ in pairs(T) do count = count + 1 end
      return count
    end
    return -1
end

--TODO komment just for dev
--[[--]]
function printTableIndex(t)
	for index,value in pairs(t) do
		print(index)
	end
end

function getAllMethodes(X)
    for key,value in pairs(getmetatable(X)) do
		print(key)
		print("Type: " .. type(value))
		if (type(value) == "table") then
			printTableIndex(value)
		else
			print(value)
		end
	end
end
