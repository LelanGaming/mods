-- Author: Julius Becker
-- Bugreports: mod@becker-julius.de

Auction={}

function Auction:new(farmlandID,name,startTime,endTime)
    setmetatable({}, Auction)
    self.__index = self
	self.auctionStartPriceRatio = 0.25
    self.betRatio = 0.05
	self.oneHoureWarningSend = false
	self.name = name
	
    self.farmlandID = farmlandID or 0
	self.normalPrice = g_farmlandManager:getFarmlandById(self.farmlandID).price
	self.maxPrice = normalPrice
	
    self.startTime = startTime
    self.endTime = endTime
	self.currentPrice = math.floor(self.normalPrice * self.auctionStartPriceRatio)
	self.currentHighestFarmID = FarmlandManager.NO_OWNER_FARM_ID
    self.betStepSize = math.floor(self.normalPrice * self.auctionStartPriceRatio * self.betRatio)
	
	self.hasStarted = false
	
	g_farmlandManager:getFarmlandById(self.farmlandID).price = self.currentPrice
	g_farmlandManager:setLandOwnership(self.farmlandID,FarmlandManager.NOT_BUYABLE_FARM_ID)
	self.allBets = {}
	Auction:generateRandomBets()

	return self
end

function Auction:auctionEnded()
	g_currentMission:addIngameNotification({1,0,0,1},g_i18n:getText("Sold") .. g_i18n:formatMoney(self.currentPrice),"SPTupdate")
	g_farmlandManager:setLandOwnership(self.farmlandID,self.currentHighestFarmID)
	if(self.currentHighestFarmID > 0)then
		local currentFarm = g_farmManager:getFarmById(self.currentHighestFarmID)
		if(currentFarm:getBalance()<self.currentPrice) then
			local missingMoney = self.currentPrice-g_farmManager:getFarmById(self.currentHighestFarmID):getBalance()
			local loanToTake = math.ceil(missingMoney/5000)*5000
			currentFarm.loan = currentFarm:getLoan()+loanToTake
			g_currentMission:addMoney(loanToTake, self.currentHighestFarmID, MoneyType.LOAN, true, true)
		end
		g_currentMission:addMoney(-self.currentPrice, self.currentHighestFarmID, MoneyType.FIELD_BUY, true, true)
	else	
		g_farmlandManager:getFarmlandById(self.farmlandID).price = self.normalPrice
	end
end

function Auction:isOutdated()
    return g_currentMission.environment:getEnvironmentTime()+g_currentMission.environment.currentDay*24 > self.endTime
end

function Auction:remainingTime()
	return self.endTime-(g_currentMission.environment:getEnvironmentTime()+g_currentMission.environment.currentDay*24)
end

function Auction:getFarmlandID()
    return self.farmlandID
end

function Auction:getNormalPrice()
    return self.normalPrice
end

function Auction:setNormalPrice(price)
    self.normalPrice = price
end

function Auction:placeBid(farmID)
	if farmID == FarmlandManager.NO_OWNER_FARM_ID or g_farmManager:getFarmById(farmID):getBalance() > (self.currentPrice + self.betStepSize) then
		self.currentPrice = math.floor(self.currentPrice + self.betStepSize)
		self.currentHighestFarmID = farmID
		g_farmlandManager:getFarmlandById(self.farmlandID).price = self.currentPrice
		if(self.currentHighestFarmID ~= FarmlandManager.NO_OWNER_FARM_ID) then
			g_currentMission:addIngameNotification({1,0.84,0,1},g_i18n:getText("Farm") .. self.currentHighestFarmID .. g_i18n:getText("HighestBidder") .. g_i18n:formatMoney(self.currentPrice) .. " Euro.","SPTupdate")
		else	
			g_currentMission:addIngameNotification({1,0,0,1}, g_npcManager:getRandomNPC().title .. g_i18n:getText("HighestBidder") .. g_i18n:formatMoney(self.currentPrice),"SPTupdate")
		end
	else
		g_currentMission:addIngameNotification({1,0.84,0,1},g_i18n:getText("NotEnoughMoney"))
	end
end

function Auction:saveToXml(pathToXML)
	local xmlID = createXMLFile("auction",pathToXML,"auction")

	setXMLFloat(xmlID,"auction.auctionStartPriceRatio",self.auctionStartPriceRatio)
	setXMLFloat(xmlID,"auction.betRatio",self.betRatio)
	setXMLFloat(xmlID,"auction.startTime",self.startTime)
	setXMLFloat(xmlID,"auction.endTime",self.endTime)
	setXMLFloat(xmlID,"auction.normalPrice",self.normalPrice)
	setXMLFloat(xmlID,"auction.currentPrice",self.currentPrice)
	setXMLFloat(xmlID,"auction.maxPrice",self.maxPrice)
	setXMLInt(xmlID,"auction.farmlandID",self.farmlandID)
	setXMLInt(xmlID, "auction.currentHighestFarmID",self.currentHighestFarmID)
	
	setXMLBool(xmlID,"auction.oneHoureWarningSend",self.oneHoureWarningSend)
	
	setXMLString(xmlID,"auction.name",self.name)
	
	for x,betTime in pairs(self.allBets) do
		setXMLFloat(xmlID,"auction.bets.bet"..x,betTime)
	end
	
	saveXMLFile(xmlID) 
	delete(xmlID) 
end

function Auction:loadFromXMLFile(pathToXML)
	local xmlID = loadXMLFile("auction", pathToXML)

	local startTime = getXMLFloat(xmlID,"auction.startTime")
	local endTime = getXMLFloat(xmlID,"auction.endTime")
	
	local farmlandID = getXMLInt(xmlID,"auction.farmlandID")
	
	local name = getXMLString(xmlID,"auction.name")
	
	local auction = Auction:new(farmlandID,name,startTime,endTime)
	
	auction.auctionStartPriceRatio = getXMLFloat(xmlID,"auction.auctionStartPriceRatio")
	auction.betRatio = getXMLFloat(xmlID,"auction.betRatio")
	auction.oneHoureWarningSend = getXMLBool(xmlID,"auction.oneHoureWarningSend")
	auction.currentHighestFarmID = getXMLInt(xmlID,"auction.currentHighestFarmID")
	auction.normalPrice = getXMLFloat(xmlID,"auction.normalPrice")
	auction.currentPrice = getXMLFloat(xmlID,"auction.currentPrice")
	auction.betStepSize = math.floor(auction.currentPrice * auction.betRatio)
	auction.maxPrice = getXMLFloat(xmlID,"auction.maxPrice")
	
	auction.allBets = {}
	local count = 1
	
	while hasXMLProperty(xmlID,"auction.bets.bet"..count) do
		auction.allBets[count] = getXMLFloat(xmlID,"auction.bets.bet"..count)
		count = count +1
	end
	delete(xmlID)
	return auction
end

function Auction:generateRandomBets()
	local costMultiplier = g_currentMission.economyManager:getCostMultiplier()
	self.maxPrice = math.random(self.normalPrice*0.8*costMultiplier,self.normalPrice*1.3*costMultiplier)
	local betCount = math.random((self.endTime-self.startTime)/5,(self.endTime-self.startTime)/15)
	self.betStepSize = self.maxPrice/betCount
	local lastTime = self.startTime
	local timeSlotSize = (self.endTime-self.startTime)/betCount
	
	for i=1,betCount do
		self.allBets[i] = lastTime+math.random(timeSlotSize)
		lastTime = lastTime+timeSlotSize
	end
	table.sort(self.allBets)
end
