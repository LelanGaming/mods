-- by modelleicher
-- 20.12.2021

productionsLimitIncreaser = {};
addModEventListener(productionsLimitIncreaser);

function productionsLimitIncreaser:loadMap(name)
	ProductionChainManager.NUM_MAX_PRODUCTION_POINTS = 120.00000;
	print("New Production Chain Limit: 120");
end;

function productionsLimitIncreaser:update(dt)
end
function productionsLimitIncreaser:deleteMap()
end;
function productionsLimitIncreaser:draw()
end;
function productionsLimitIncreaser:mouseEvent(posX, posY, isDown, isUp, button)
end;
function productionsLimitIncreaser:keyEvent(unicode, sym, modifier, isDown)
end;



