--
-- FS22 - Timber Trailer Info
-- @author:    	kenny456 (kenny456@seznam.cz)
-- @history:	v1.0.0.0 - 2021-12-12 - fs22 conversion
--
TimberTrailerInfo = {}
TimberTrailerInfo.confDir = getUserProfileAppPath().. "modsSettings/TimberTrailerInfo/"
TimberTrailerInfo.modDirectory = g_currentModDirectory
TimberTrailerInfo.vehicles = {}
TimberTrailerInfo.showHelp = true
local modName = g_currentModName

function TimberTrailerInfo.prerequisitesPresent(specializations)
	return true
end
function TimberTrailerInfo.registerOverwrittenFunctions(vehicleType)
end
function TimberTrailerInfo.registerFunctions(vehicleType)
	SpecializationUtil.registerFunction(vehicleType, "logTriggerCallback", 	TimberTrailerInfo.logTriggerCallback)
	SpecializationUtil.registerFunction(vehicleType, "updateHudValuesTTI", 	TimberTrailerInfo.updateHudValuesTTI)
	SpecializationUtil.registerFunction(vehicleType, "saveToXmlTTI", 		TimberTrailerInfo.saveToXmlTTI)
	SpecializationUtil.registerFunction(vehicleType, "loadFromXmlTTI", 		TimberTrailerInfo.loadFromXmlTTI)
end
function TimberTrailerInfo:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	if spec.event_IDs == nil then
		spec.event_IDs = {}
	else
		self:clearActionEventsTable(spec.event_IDs)
	end
	if self:getIsActiveForInput() or (self.getIscontrolled ~= nil and self:getIsControlled()) then
		self:loadFromXmlTTI(self:getFullName())
		self:updateHudValuesTTI()
		if g_dedicatedServerInfo ~= nil then
			return
		end
		local actions = { InputAction.TIMBER_TRAILER_INFO_TOGGLE_ACTIVE, InputAction.TIMBER_TRAILER_INFO_TOGGLE_SIZE, InputAction.TIMBER_TRAILER_INFO_TOGGLE_STATS, InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_TRIGGER, InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_LEFT, InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_RIGHT,
								InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_UP, InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_DOWN }
		for _,actionName in pairs(actions) do
			local always = (actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_TRIGGER or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_LEFT or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_RIGHT or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_UP or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_DOWN) and true or false
			local _, eventID = g_inputBinding:registerActionEvent(actionName, self, TimberTrailerInfo.actionCallback, true, true, always, true)
			spec.event_IDs[actionName] = eventID
			if g_inputBinding ~= nil and g_inputBinding.events ~= nil and g_inputBinding.events[eventID] ~= nil then
				if actionName == 'something with lower priority' then
					g_inputBinding:setActionEventTextPriority(eventID, GS_PRIO_NORMAL)
				else
					g_inputBinding:setActionEventTextPriority(eventID, GS_PRIO_VERY_HIGH)
				end
				g_inputBinding:setActionEventTextVisibility(eventID, TimberTrailerInfo.showHelp)
			end
			local colliding = false
			_, colliding, _ = g_inputBinding:checkEventCollision(actionName)
			if colliding then
				if g_inputBinding.nameActions[actionName].bindings[1] ~= nil then
					if g_inputBinding.nameActions[actionName].bindings[1].inputString ~= nil then
						print(string.format('Warning: TimberTrailerInfo got a colliding input action: %s', actionName)..' ('..g_inputBinding.nameActions[actionName].bindings[1].inputString..'). You can remap it in controls settings')
					end
				else
					print(string.format('Warning: TimberTrailerInfo got a colliding input action: %s', actionName))
				end
			end
		end
	end
end
function TimberTrailerInfo.registerEventListeners(vehicleType)
	for _,n in pairs( { "onLoad", "onPostLoad", "saveToXMLFile", "onUpdate", "onUpdateTick", "onDraw", "onReadStream", "onWriteStream", "onRegisterActionEvents" } ) do
		SpecializationUtil.registerEventListener(vehicleType, n, TimberTrailerInfo)
	end
end
function TimberTrailerInfo:onLoad(savegame)
	self.spec_timberTrailerInfo = {}
	local spec = self.spec_timberTrailerInfo
	
	self.delete = Utils.prependedFunction(self.delete, TimberTrailerInfo.onDeleteTTI)
	spec.hud = createImageOverlay(TimberTrailerInfo.modDirectory .. "images/hud.dds")
	spec.ui = g_gameSettings.uiScale
	TimberTrailerInfo.size = 1
	TimberTrailerInfo.maxSize = 1.4
	TimberTrailerInfo.minSize = 0.8
	TimberTrailerInfo.shiftX = -0.115
	TimberTrailerInfo.shiftY = 0.623
	spec.hudTextCenter = ''
	spec.hudText1 = ''
	spec.hudText2 = ''
end
function TimberTrailerInfo:onPostLoad(savegame)
	local spec = self.spec_timberTrailerInfo

	spec.modInitialized = false
	spec.modAllowed = true
	if SpecializationUtil.hasSpecialization(TensionBelts, self.specializations) and self.spec_tensionBelts ~= nil then
		spec.modInitialized = true
	end
	if not spec.modInitialized then
		print("Error: TimberTrailerInfo initialization failed for "..tostring(self:getFullName()).." ! "..tostring(SpecializationUtil.hasSpecialization(DynamicMountAttacher, self.specializations)))
		return
	end
	
	spec.triggerFile = g_i3DManager:loadSharedI3DFile(TimberTrailerInfo.modDirectory..'logTrigger.i3d', true, false)
	spec.logTrigger = I3DUtil.indexToObject(spec.triggerFile, '0|0')
	addTrigger(spec.logTrigger, "logTriggerCallback", self)
	if self.spec_tensionBelts.sortedBelts ~= nil then
		local x,y,z = getTranslation(self.spec_tensionBelts.sortedBelts[1].startNode)
		local a,b,c = getTranslation(self.spec_tensionBelts.sortedBelts[#self.spec_tensionBelts.sortedBelts].startNode)
		local length = z - c
		local middle = z - (length / 2)
		link(getParent(self.spec_tensionBelts.sortedBelts[1].startNode), spec.logTrigger)
		setTranslation(spec.logTrigger, 0,y+1.25,middle)
		setScale(spec.logTrigger, 1,1,length*0.1*1.2)
	end
	spec.modActive = true
	spec.woodLoad = {}
	spec.logs = {}
	spec.logs[1] = 0
	spec.logs[2] = 0
	spec.logsMass = {}
	spec.logsMass[1] = 0
	spec.logsMass[2] = 0
	spec.logsVolume = {}
	spec.logsVolume[1] = 0
	spec.logsVolume[2] = 0
	TimberTrailerInfo.logs = {}
	TimberTrailerInfo.logs[1] = 0
	TimberTrailerInfo.logs[2] = 0
	TimberTrailerInfo.logsMass = {}
	TimberTrailerInfo.logsMass[1] = 0
	TimberTrailerInfo.logsMass[2] = 0
	TimberTrailerInfo.logsVolume = {}
	TimberTrailerInfo.logsVolume[1] = 0
	TimberTrailerInfo.logsVolume[2] = 0
	spec.timer = 0
	spec.firstGame = false
	TimberTrailerInfo.showStats = true
	spec.moveHudTrigger = false
	spec.timerHud = 0
	
	if self.spec_autoLoadWood ~= nil then
		spec.modActive = false
	end
	if savegame ~= nil then
		local xmlFile = savegame.xmlFile
		local key = savegame.key.."."..modName..".TimberTrailerInfo"
		spec.modActive = Utils.getNoNil(getXMLBool(xmlFile.handle, key.."#modActive"), spec.modActive)
		spec.logs[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#logs"), spec.logs[2])
		spec.logsMass[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#mass"), spec.logsMass[2])
		spec.logsVolume[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#vol"), spec.logsVolume[2])
		TimberTrailerInfo.logs[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#logsTotal"), TimberTrailerInfo.logs[2])
		TimberTrailerInfo.logsMass[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#massTotal"), TimberTrailerInfo.logsMass[2])
		TimberTrailerInfo.logsVolume[2] = Utils.getNoNil(getXMLFloat(xmlFile.handle, key.."#volTotal"), TimberTrailerInfo.logsVolume[2])
		if spec.logs[2] == 0 then
			spec.firstGame = true
		end
	end
		if self.isClient and g_dedicatedServerInfo == nil then
		local configFile = TimberTrailerInfo.confDir .. "TimberTrailerInfoConfig.xml"
		if fileExists(configFile) then
			self:loadFromXmlTTI(self:getFullName())
		else
			createFolder(getUserProfileAppPath().. "modsSettings/")
			createFolder(TimberTrailerInfo.confDir)
			TimberTrailerInfo.configXml = createXMLFile("TimberTrailerInfo_XML", configFile, "TimberTrailerInfoConfig")
			self:saveToXmlTTI()
		end
	end

	self:updateHudValuesTTI()
end
function TimberTrailerInfo:onDeleteTTI()
	local spec = self.spec_timberTrailerInfo
	
	if spec.logTrigger ~= nil then
		removeTrigger(spec.logTrigger)
	end
end
function TimberTrailerInfo:saveToXMLFile(xmlFile, key)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	setXMLBool(xmlFile.handle, key.."#modActive", spec.modActive)
	setXMLFloat(xmlFile.handle, key.."#logs", spec.logs[2])
	setXMLFloat(xmlFile.handle, key.."#mass", spec.logsMass[2])
	setXMLFloat(xmlFile.handle, key.."#vol", spec.logsVolume[2])
	setXMLFloat(xmlFile.handle, key.."#logsTotal", TimberTrailerInfo.logs[2])
	setXMLFloat(xmlFile.handle, key.."#massTotal", TimberTrailerInfo.logsMass[2])
	setXMLFloat(xmlFile.handle, key.."#volTotal", TimberTrailerInfo.logsVolume[2])
end
function TimberTrailerInfo:loadFromXmlTTI(vehicle)
	local spec = self.spec_timberTrailerInfo
	
	local configFile = TimberTrailerInfo.confDir .. "TimberTrailerInfoConfig.xml";
    if self.isClient and g_dedicatedServerInfo == nil and fileExists(configFile) then
		TimberTrailerInfo.configXml = loadXMLFile("TimberTrailerInfo_XML", configFile);
		if getXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showHelp") ~= nil then
			TimberTrailerInfo.showHelp = getXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showHelp")
		end
		if getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftX") ~= nil then
			TimberTrailerInfo.shiftX = getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftX")
		end
		if getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftY") ~= nil then
			TimberTrailerInfo.shiftY = getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftY")
		end
		if getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.size") ~= nil then
			TimberTrailerInfo.size = getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.size")
		end
		if getXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showStats") ~= nil then
			TimberTrailerInfo.showStats = getXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showStats")
		end
		if vehicle ~= nil then
			local key = "TimberTrailerInfoConfig.activeVehicles"
			local i = 0
			while true do
				local name = getXMLString(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i).."#name");
				if name ~= nil then
					if name == vehicle then
						spec.modActive = getXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i));
						break
					end
				else
					break
				end
				i = i + 1
			end
		end
	end
end
function TimberTrailerInfo:saveToXmlTTI(vehicle, active)
	local spec = self.spec_timberTrailerInfo
    
	if self.isClient and TimberTrailerInfo.configXml ~= nil and g_dedicatedServerInfo == nil then
		setXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showHelp", TimberTrailerInfo.showHelp)
		setXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftX", TimberTrailerInfo.shiftX)
		setXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.shiftY", TimberTrailerInfo.shiftY)
		setXMLFloat(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.size", TimberTrailerInfo.size)
		setXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.showStats", TimberTrailerInfo.showStats)
		if vehicle ~= nil and active ~= nil then
			local key = "TimberTrailerInfoConfig.activeVehicles"
			local i = 0
			while true do
				local name = getXMLString(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i).."#name")
				if name ~= nil then
					if name == vehicle then
						setXMLString(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i).."#name", vehicle)
						setXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i), active)
						break
					end
				else
					setXMLString(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i).."#name", vehicle)
					setXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i), active)
					break
				end
				i = i + 1
				local name = key .. string.format(".vehicle(%d)", i)
				if not hasXMLProperty(TimberTrailerInfo.configXml, name) then
					setXMLString(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i).."#name", vehicle)
					setXMLBool(TimberTrailerInfo.configXml, "TimberTrailerInfoConfig.activeVehicles"..string.format(".vehicle(%d)", i), active)
					break
				end
			end
		end
		saveXMLFile(TimberTrailerInfo.configXml)
	end
end
function TimberTrailerInfo:onUpdate(dt)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	if spec.timer < 2000 then
		spec.timer = spec.timer + dt
	end
	--[[if self:getIsActive() then
		spec.infoText = ""
		spec.infoText = spec.infoText .. 'logsSession- '..spec.logs[1]..'\n'
		spec.infoText = spec.infoText .. 'logsTotal - '..spec.logs[2]..'\n'
		spec.infoText = spec.infoText .. 'logsMassSession - '..spec.logsMass[1]..'\n'
		spec.infoText = spec.infoText .. 'logsMassTotal - '..spec.logsMass[2]..'\n'
		spec.infoText = spec.infoText .. 'logsVolumeSession - '..spec.logsVolume[1]..'\n'
		spec.infoText = spec.infoText .. 'logsVolumeTotal - '..spec.logsVolume[2]..'\n'
		spec.infoText = spec.infoText .. '------------------------------------\n'
		spec.infoText = spec.infoText .. 'logsSession- '..TimberTrailerInfo.logs[1]..'\n'
		spec.infoText = spec.infoText .. 'logsTotal - '..TimberTrailerInfo.logs[2]..'\n'
		spec.infoText = spec.infoText .. 'logsMassSession - '..TimberTrailerInfo.logsMass[1]..'\n'
		spec.infoText = spec.infoText .. 'logsMassTotal - '..TimberTrailerInfo.logsMass[2]..'\n'
		spec.infoText = spec.infoText .. 'logsVolumeSession - '..TimberTrailerInfo.logsVolume[1]..'\n'
		spec.infoText = spec.infoText .. 'logsVolumeTotal - '..TimberTrailerInfo.logsVolume[2]..'\n'
		renderText(0.7080, 0.8205, 0.017, spec.infoText)
	end]]
	local count = 0
	local mass = 0
	local volume = 0
	if spec.modActive then
		if self:getIsActive() then
			for k, shape in pairs(spec.woodLoad) do
				if entityExists(shape) then
					count = count + 1
					mass = mass + getMass(shape)
					volume = volume + getVolume(shape)
				else
					spec.woodLoad[k] = nil
				end
			end
		end
	end

	if self.isClient then
		if self:getIsActiveForInput() or (self.getIscontrolled ~= nil and self:getIsControlled()) then
			if spec.event_IDs ~= nil and g_dedicatedServerInfo == nil then
				for actionName,eventID in pairs(spec.event_IDs) do
					g_inputBinding:setActionEventTextVisibility(eventID, TimberTrailerInfo.showHelp)
					if actionName == InputAction.TIMBER_TRAILER_INFO_TOGGLE_ACTIVE then
						g_inputBinding:setActionEventActive(eventID, true)
						g_inputBinding:setActionEventText(eventID, spec.modActive and g_i18n:getText('TIMBER_TRAILER_INFO_DEACTIVATE') or g_i18n:getText('TIMBER_TRAILER_INFO_ACTIVATE'))
					elseif actionName == InputAction.TIMBER_TRAILER_INFO_TOGGLE_SIZE then
local sizeText = TimberTrailerInfo.size == 0.8 and g_i18n:getText('TIMBER_TRAILER_INFO_HUD_SMALL') or (TimberTrailerInfo.size == 1 and g_i18n:getText('TIMBER_TRAILER_INFO_HUD_NORMAL') or (TimberTrailerInfo.size == 1.2 and g_i18n:getText('TIMBER_TRAILER_INFO_HUD_LARGE') or (TimberTrailerInfo.size == 1.4 and g_i18n:getText('TIMBER_TRAILER_INFO_HUD_LARGER') or g_i18n:getText('TIMBER_TRAILER_INFO_HUD_CUSTOM'))))
						g_inputBinding:setActionEventActive(eventID, (TimberTrailerInfo.showStats and spec.modActive) and true or false)
						g_inputBinding:setActionEventText(eventID, g_i18n:getText('input_TIMBER_TRAILER_INFO_TOGGLE_SIZE')..' : '..sizeText)
					elseif actionName == InputAction.TIMBER_TRAILER_INFO_TOGGLE_STATS then
						g_inputBinding:setActionEventActive(eventID, spec.modActive and true or false)
						g_inputBinding:setActionEventText(eventID, TimberTrailerInfo.showStats and g_i18n:getText('TIMBER_TRAILER_INFO_HIDE_STATS') or g_i18n:getText('TIMBER_TRAILER_INFO_SHOW_STATS'))
					elseif actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_TRIGGER then
						g_inputBinding:setActionEventActive(eventID, (spec.modActive and TimberTrailerInfo.showStats) and true or false)
						g_inputBinding:setActionEventTextVisibility(eventID, not spec.moveHudTrigger)
					elseif actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_LEFT or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_RIGHT or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_UP or actionName == InputAction.TIMBER_TRAILER_INFO_MOVE_HUD_DOWN then
						g_inputBinding:setActionEventActive(eventID, spec.moveHudTrigger and spec.modActive)

					end
				end
			end
			if spec.modActive then
				if count > 0 then
					g_currentMission:addExtraPrintText(g_i18n:getText('TIMBER_TRAILER_INFO_COUNT').." "..count.." ("..string.format('%.1f', mass).." t / "..string.format('%.1f', volume).." m3)")
				else
					g_currentMission:addExtraPrintText(g_i18n:getText('TIMBER_TRAILER_INFO_NO_LOGS'))
				end
			end
		end
		if spec.inputLeft or spec.inputRight or spec.inputUp or spec.inputDown then
			local x = TimberTrailerInfo.shiftX
			local y = TimberTrailerInfo.shiftY
			spec.timerHud = spec.timerHud + dt
			if spec.inputLeft then
				if spec.timerHud > 1500 then
					x = x + 0.001
				else
					x = x + 0.0001
				end
			end
			if spec.inputRight then
				if spec.timerHud > 1500 then
					x = x - 0.001
				else
					x = x - 0.0001
				end
			end
			if spec.inputUp then
				if spec.timerHud > 1500 then
					y = y - 0.001
				else
					y = y - 0.0001
				end
			end
			if spec.inputDown then
				if spec.timerHud > 1500 then
					y = y + 0.001
				else
					y = y + 0.0001
				end
			end
			TimberTrailerInfo.shiftX = x
			TimberTrailerInfo.shiftY = y
			self:updateHudValuesTTI()
		else
			spec.timerHud = 0
		end
	end
end
function TimberTrailerInfo:logTriggerCallback(triggerId, otherActorId, onEnter, onLeave, onStay, otherShapeId)
	local spec = self.spec_timberTrailerInfo
	
	local splitType = g_splitTypeManager:getSplitTypeByIndex(getSplitType(otherActorId))
	if splitType ~= nil then
		if onEnter then
			if spec.woodLoad[otherActorId] == nil then
				spec.woodLoad[otherActorId] = otherActorId
				if spec.timer > 2000 or spec.firstGame then
				spec.logs[1] = spec.logs[1] + 1
				spec.logs[2] = spec.logs[2] + 1
				spec.logsMass[1] = spec.logsMass[1] + getMass(otherActorId)
				spec.logsMass[2] = spec.logsMass[2] + getMass(otherActorId)
				spec.logsVolume[1] = spec.logsVolume[1] + getVolume(otherActorId)
				spec.logsVolume[2] = spec.logsVolume[2] + getVolume(otherActorId)
				TimberTrailerInfo.logs[1] = TimberTrailerInfo.logs[1] + 1
				TimberTrailerInfo.logs[2] = TimberTrailerInfo.logs[2] + 1
				TimberTrailerInfo.logsMass[1] = TimberTrailerInfo.logsMass[1] + getMass(otherActorId)
				TimberTrailerInfo.logsMass[2] = TimberTrailerInfo.logsMass[2] + getMass(otherActorId)
				TimberTrailerInfo.logsVolume[1] = TimberTrailerInfo.logsVolume[1] + getVolume(otherActorId)
				TimberTrailerInfo.logsVolume[2] = TimberTrailerInfo.logsVolume[2] + getVolume(otherActorId)
			end
			end
		elseif onLeave then
			if spec.woodLoad[otherActorId] ~= nil then
				spec.woodLoad[otherActorId] = nil
			end
		end
	end
end
function TimberTrailerInfo:onUpdateTick(dt)
end
function TimberTrailerInfo:actionCallback(actionName, keyStatus, arg4, arg5, arg6)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	if self:getIsActive() then
		if keyStatus > 0 then
			if actionName == 'TIMBER_TRAILER_INFO_TOGGLE_ACTIVE' then
				spec.modActive  = not spec.modActive
				self:saveToXmlTTI(self:getFullName(), spec.modActive)
			elseif actionName == 'TIMBER_TRAILER_INFO_TOGGLE_SIZE' then
				if TimberTrailerInfo.size + 0.2 <= TimberTrailerInfo.maxSize then
					TimberTrailerInfo.size = TimberTrailerInfo.size + 0.2
				else
					TimberTrailerInfo.size = TimberTrailerInfo.minSize
				end
				self:saveToXmlTTI()
				self:updateHudValuesTTI()
			elseif actionName == 'TIMBER_TRAILER_INFO_TOGGLE_STATS' then
				TimberTrailerInfo.showStats = not TimberTrailerInfo.showStats
				self:saveToXmlTTI()
			end
		end
	end
	if actionName == 'TIMBER_TRAILER_INFO_MOVE_HUD_TRIGGER' then
		spec.moveHudTrigger = keyStatus > 0
	elseif actionName == 'TIMBER_TRAILER_INFO_MOVE_HUD_LEFT' then
		spec.inputLeft = keyStatus > 0
		if keyStatus == 0 then self:saveToXmlTTI() end
	elseif actionName == 'TIMBER_TRAILER_INFO_MOVE_HUD_RIGHT' then
		spec.inputRight = keyStatus > 0
		if keyStatus == 0 then self:saveToXmlTTI() end
	elseif actionName == 'TIMBER_TRAILER_INFO_MOVE_HUD_UP' then
		spec.inputUp = keyStatus > 0
		if keyStatus == 0 then self:saveToXmlTTI() end
	elseif actionName == 'TIMBER_TRAILER_INFO_MOVE_HUD_DOWN' then
		spec.inputDown = keyStatus > 0
		if keyStatus == 0 then self:saveToXmlTTI() end
	else
		spec.moveHudTrigger = false
	end
end
function TimberTrailerInfo:updateHudValuesTTI()
	local spec = self.spec_timberTrailerInfo
	
	spec.sizeHud = TimberTrailerInfo.size * spec.ui
	spec.positionX = g_currentMission.inGameMenu.hud.speedMeter.gaugeCenterX - TimberTrailerInfo.shiftX
	spec.positionY = g_currentMission.inGameMenu.hud.speedMeter.gaugeCenterX - TimberTrailerInfo.shiftY
	spec.hudWidth = 0.16 * spec.sizeHud
	spec.hudHeight = 0.12 * spec.sizeHud
	spec.hudX = spec.positionX - spec.hudWidth
	spec.hudY = spec.positionY
	spec.hudTextCenterX = spec.hudX + (0.078 * spec.sizeHud)
	spec.hudTextCenterY = spec.hudY + (0.103 * spec.sizeHud)
	spec.hudText1X = spec.hudX + (0.003 * spec.sizeHud)
	spec.hudText1Y = spec.hudY + (0.072 * spec.sizeHud)
	spec.hudText2X = spec.hudX + (0.06 * spec.sizeHud)
	spec.hudText2Y = spec.hudY + (0.072 * spec.sizeHud)
end
function TimberTrailerInfo:onDraw()
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	if spec.modActive and TimberTrailerInfo.showStats then
		renderOverlay(spec.hud, spec.hudX, spec.hudY, spec.hudWidth, spec.hudHeight)
		spec.hudTextCenter = spec.hudTextCenter .. 'Total Logs Transported\n'
		spec.hudTextCenter = spec.hudTextCenter .. 'All Vehicles\n\n\n'
		spec.hudTextCenter = spec.hudTextCenter .. 'Current Vehicle\n\n\n'
		spec.hudText1 = spec.hudText1 .. 'This Session:\n'
		spec.hudText1 = spec.hudText1 .. 'Total:\n\n'
		spec.hudText1 = spec.hudText1 .. 'This Session:\n'
		spec.hudText1 = spec.hudText1 .. 'Total:\n'
		local text = TimberTrailerInfo.logs[1] > 20 and '%.0f' or '%.1f'
		spec.hudText2 = spec.hudText2 .. TimberTrailerInfo.logs[1]..' ('..string.format(text, TimberTrailerInfo.logsMass[1])..' t / '..string.format(text, TimberTrailerInfo.logsVolume[1])..' m3)\n'
		local text = TimberTrailerInfo.logs[2] > 20 and '%.0f' or '%.1f'
		spec.hudText2 = spec.hudText2 .. TimberTrailerInfo.logs[2]..' ('..string.format(text, TimberTrailerInfo.logsMass[2])..' t / '..string.format(text, TimberTrailerInfo.logsVolume[2])..' m3)\n\n'
		local text = spec.logs[1] > 20 and '%.0f' or '%.1f'
		spec.hudText2 = spec.hudText2 .. spec.logs[1]..' ('..string.format(text, spec.logsMass[1])..' t / '..string.format(text, spec.logsVolume[1])..' m3)\n'
		local text = spec.logs[2] > 20 and '%.0f' or '%.1f'
		spec.hudText2 = spec.hudText2 .. spec.logs[2]..' ('..string.format(text, spec.logsMass[2])..' t / '..string.format(text, spec.logsVolume[2])..' m3)\n\n'
		setTextAlignment(RenderText.ALIGN_CENTER)
		renderText(spec.hudTextCenterX, spec.hudTextCenterY, 0.015*spec.sizeHud, spec.hudTextCenter)
		setTextAlignment(RenderText.ALIGN_LEFT)
		--setTextBold(true)
		setTextColor(1, 1, 1, 1)
		renderText(spec.hudText1X, spec.hudText1Y, 0.015*spec.sizeHud, spec.hudText1)
		renderText(spec.hudText2X, spec.hudText2Y, 0.015*spec.sizeHud, spec.hudText2)
		spec.hudTextCenter = ''
		spec.hudText1 = ''
		spec.hudText2 = ''
	end
end
function TimberTrailerInfo:onReadStream(streamId, connection)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
end
function TimberTrailerInfo:onWriteStream(streamId, connection)
	local spec = self.spec_timberTrailerInfo
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
end